// config.js
const config = {
    baseUrl: "http://localhost:3000", // Default URL for local development
};

module.exports = config;
